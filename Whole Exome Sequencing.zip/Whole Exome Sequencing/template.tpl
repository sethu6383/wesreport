<!doctype html>
<html lang="">

<head>
  <meta charset="utf-8">
  <title>{{reportName}}</title>
  <meta name="description" content="{{reportName}}">
  <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
  <link rel="stylesheet" href="styles/custom.css">
</head>

<body>
  <table class="main-table">
    {{!-- Add 4 columns so colspan can be used for layout --}}
    <colgroup>
      <col width="25%">
      <col width="25%">
      <col width="25%">
      <col width="25%">
    </colgroup>
    <thead>
      <tr>
        <td colspan="2">
            <img class="logo" src="data:image/png;base64,{{lab.logo.data}}" alt="">
        </td>
        <td colspan="2" class="text-sm">
          <div class="blue-text text-sm">{{lab.name.data}}</div>
          <div>{{lab.address.data}}</div>
          <div>{{lab.details1.data}}</div>
          <div>{{lab.details2.data}}</div>
        </td>
      </tr>
      <tr>
        <td colspan="2" class="text-lg">
          <span class="gray-text">Name: </span>
          <span class="bold-text">{{patient.name.data}}</span>
        </td>
        <td colspan="2" class="text-lg">
          <span class="gray-text">Accession ID: </span>
          <span class="bold-text">{{patient.accessionID.data}}</span>
        </td>
      </tr>
    </thead>
    <tbody>
      <tr class="text-sm">
        <td class="top-space">
          <span class="gray-text">DOB: </span>
          <span class="bold-text">{{dateFormat patient.dob.data}}</span>
        </td>
        <td class="top-space">
          <span class="gray-text">{{patient.mrn.label}}: </span>
          <span class="bold-text">{{patient.mrn.data}}</span>
        </td>
        <td class="top-space">
          <span class="gray-text">{{sample.coverage.label}}: </span>
          <span class="bold-text">{{sample.coverage.data}}</span>
        </td>
        <td class="top-space">
          <span class="gray-text">{{sample.collectionDate.label}}: </span>
          <span class="bold-text">{{dateFormat sample.collectionDate.data}}</span>
        </td>
      </tr>
      <tr class="text-sm">
        <td>
          <span class="gray-text">{{patient.sex.label}}: </span>
          <span class="bold-text">{{patient.sex.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{patient.facility.label}}: </span>
          <span class="bold-text">{{patient.facility.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{sample.avgDp.label}}: </span>
          <span class="bold-text">{{sample.avgDp.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{sample.receiptDate.label}}: </span>
          <span class="bold-text">{{dateFormat sample.receiptDate.data}}</span>
        </td>
      </tr>
      <tr class="text-sm">
        <td>
          <span class="gray-text">{{patient.race.label}}: </span>
          <span class="bold-text">{{patient.race.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{patient.physician.label}}: </span>
          <span class="bold-text">{{patient.physician.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{sample.specimen.label}}: </span>
          <span class="bold-text">{{sample.specimen.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{sample.reportDate.label}}: </span>
          <span class="bold-text">{{dateFormat sample.reportDate.data}}</span>
        </td>
      </tr>
      <tr class="text-sm">
        <td>
          <span class="gray-text">{{patient.familyNumber.label}}: </span>
          <span class="bold-text">{{patient.familyNumber.data}}</span>
        </td>
        <td>
          <span class="gray-text">{{patient.copies.label}}: </span>
          <span class="bold-text">{{patient.copies.data}}</span>
        </td>
        <td></td>
        <td></td>
      </tr>
      <tr class="text-sm">
        <td colspan="4" class="top-space">
          <span class="gray-text">{{test.name.label}}: </span>
          <span class="bold-text">{{test.name.data}}</span>
        </td>
      </tr>
      <tr class="text-sm">
        <td colspan="4">
          <span class="gray-text">{{patient.indication.label}}: </span> 
          <span class="bold-text">{{patient.indication.data}}</span>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space">
          <div class="results-box center-text {{lower results.result.data}}">
            <div class="text-lg bold-text">RESULT: {{results.result.data}}</div>
            <div class="text-md">{{results.resultNote.data}}</div>
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm top-space">
          <div class="text-md blue-text bold-text bottom-space">APPROACH</div>
          {{test.approach.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm top-space">
          <div class="text-md blue-text bold-text bottom-space">VARIANTS RELEVANT TO INDICATION FOR TESTING</div>
          {{results.summary.data}}
        </td>
      </tr>
      {{#ifCond variants.length '||' cnvPrimary}} 
      <tr>
        <td colspan="4">
          <table class="variant-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              {{#each variants}}
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exon}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              {{/each}}
              {{#each cnvs}} {{#if this.primary}}
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              {{/if}} {{/each}}
          </table>
        </td>
      </tr>
      {{/ifCond}}
      <tr>
        <td colspan="4" class="text-sm">
          <div class="text-md blue-text bold-text bottom-space">OTHER VARIANTS OF MEDICAL SIGNIFICANCE (INCIDENTAL FINDINGS)</div>
          {{results.summaryIncidental.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space">
          <span class="text-md-sm blue-text bold-text">Monogenic Disease Risk</span>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm">
          {{results.summaryMonogenicDiseaseRisk.data}}
        </td>
      </tr>
      {{#if monogenicDiseaseRisk}} 
      <tr>
        <td colspan="4">
          <table class="variant-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              {{#each incidental}} {{#if this.monogenicDiseaseRisk}}
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exon}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
             {{/if}} {{/each}}
             {{#each cnvs}} {{#ifCond this.incidental '&&' this.monogenicDiseaseRisk}}
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
            {{/ifCond}} {{/each}}
          </table>
        </td>
      </tr>
      {{/if}}
      <tr>
        {{#if monogenicDiseaseRisk}} 
        <td colspan="4">
        {{else}}
        <td colspan="4" class="top-space">
        {{/if}}          
          <span class="text-md-sm blue-text bold-text">Carrier Status</span>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm">
          {{results.summaryCarrierStatus.data}}
        </td>
      </tr>
      {{#if carrierStatus}} 
      <tr>
        <td colspan="4">
          <table class="variant-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              {{#each incidental}} {{#unless this.monogenicDiseaseRisk}}
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exon}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
             {{/unless}} {{/each}}
             {{#each cnvs}} {{#if this.incidental}} {{#unless this.monogenicDiseaseRisk}}
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
            {{/unless}} {{/if}} {{/each}}
          </table>
        </td>
      </tr>
      {{/if}}
      <tr>
        </td>
      </tr>
      <tr>
        {{#if carrierStatus}} 
        <td colspan="4" class="text-sm">
        {{else}}
        <td colspan="4" class="text-sm top-space">
        {{/if}}
          <div class="text-md blue-text bold-text bottom-space">RECOMMENDATIONS</div>
          {{test.recommendations.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space">
          <span class="text-md blue-text bold-text">DETAILED VARIANT INFORMATION (VARIANTS RELEVANT TO INDICATION FOR TESTING)</span>
        </td>
      </tr>
      {{#ifCond variants.length '||' cnvPrimary}} 
      {{#each variants}}
      <tr>
        <td colspan="4">
          <table class="variant-table variant-details-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="140">
              <col width="195">
              <col width="130">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Inheritance</th>
                <th>Disorder or Phenotype</th>
                <th>Criteria</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.criteria}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th>Location</th>
                <th>Allele State</th>
                <th colspan="4">Allelic Read Depths</th>
              </tr>
              <tr>
                <td>{{this.exon}}</td>
                <td>{{this.zygosity}}</td>
                <td colspan="4">{{this.allelicReadDepths}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="3" class="padded-cell">Variant Frequency</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.hgvsG}}</td>
                <td colspan="3">
                  {{#if this.maxAlleleFreq}}
                    {{this.maxAlleleFreq}} max frequency observed in {{this.maxPop}}
                  {{else}}
                    Not identified in large population studies
                  {{/if}}
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/each}}
      {{#each cnvs}} {{#if this.primary}}
      <tr>
        <td colspan="4">
          <table class="variant-table">
             <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="4" class="padded-cell">Ratio / Z-Score compared to Reference Samples, Mean Read Depth</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.start}}-{{this.stop}}</td>
                <td colspan="4">
                  {{this.ratio}} Ratio, {{this.zScore}} Z-Score, {{this.meanReadDepth}} Mean Read Depth
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/if}} {{/each}} 
      {{/ifCond}}
      {{#ifCond incidental.length '||' cnvIncidental}} 
      <tr>
        <td colspan="4">
          <span class="text-md blue-text bold-text">DETAILED VARIANT INFORMATION (INCIDENTAL FINDINGS)</span>
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space">
          <span class="text-md-sm blue-text bold-text">Monogenic Disease Risk</span>
        </td>
      </tr>
      {{#unless monogenicDiseaseRisk}}
      <tr>
        <td colspan="4" class="text-sm">
          {{results.summaryMonogenicDiseaseRisk.data}}
        </td>
      </tr>
      {{/unless}}
      {{#each incidental}}{{#if this.monogenicDiseaseRisk}}
      <tr>
        <td colspan="4">
          <table class="variant-table variant-details-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="140">
              <col width="195">
              <col width="130">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Inheritance</th>
                <th>Disorder or Phenotype</th>
                <th>Criteria</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.criteria}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th>Location</th>
                <th>Allele State</th>
                <th colspan="4">Allelic Read Depths</th>
              </tr>
              <tr>
                <td>{{this.exon}}</td>
                <td>{{this.zygosity}}</td>
                <td colspan="4">{{this.allelicReadDepths}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="3" class="padded-cell">Variant Frequency</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.hgvsG}}</td>
                <td colspan="3">
                  {{#if this.maxAlleleFreq}}
                    {{this.maxAlleleFreq}} max frequency observed in {{this.maxPop}}
                  {{else}}
                    Not identified in large population studies
                  {{/if}}
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/if}}{{/each}}
      {{#each cnvs}} {{#ifCond this.incidental '&&' this.monogenicDiseaseRisk}}
      <tr>
        <td colspan="4">
          <table class="variant-table">
             <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="4" class="padded-cell">Ratio / Z-Score compared to Reference Samples, Mean Read Depth</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.start}}-{{this.stop}}</td>
                <td colspan="4">
                  {{this.ratio}} Ratio, {{this.zScore}} Z-Score, {{this.meanReadDepth}} Mean Read Depth
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/ifCond}} {{/each}} 
      <tr>
        {{#if monogenicDiseaseRisk}}
        <td colspan="4">
        {{else}}
        <td colspan="4" class="top-space">
        {{/if}}
          <span class="text-md-sm blue-text bold-text">Carrier Status</span>
        </td>
      </tr>
      {{#unless carrierStatus}}
      <tr>
        <td colspan="4" class="text-sm">
          {{results.summaryCarrierStatus.data}}
        </td>
      </tr>
      {{/unless}}
      {{#each incidental}}{{#unless this.monogenicDiseaseRisk}}
      <tr>
        <td colspan="4">
          <table class="variant-table variant-details-table">
            <colgroup>
              <col width="140">
              <col width="140">
              <col width="140">
              <col width="195">
              <col width="130">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Inheritance</th>
                <th>Disorder or Phenotype</th>
                <th>Criteria</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.gene}}<br/>{{this.transcript}}</td>
                <td>{{this.hgvsC}}<br/>{{this.hgvsP}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.criteria}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th>Location</th>
                <th>Allele State</th>
                <th colspan="4">Allelic Read Depths</th>
              </tr>
              <tr>
                <td>{{this.exon}}</td>
                <td>{{this.zygosity}}</td>
                <td colspan="4">{{this.allelicReadDepths}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="3" class="padded-cell">Variant Frequency</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.hgvsG}}</td>
                <td colspan="3">
                  {{#if this.maxAlleleFreq}}
                    {{this.maxAlleleFreq}} max frequency observed in {{this.maxPop}}
                  {{else}}
                    Not identified in large population studies
                  {{/if}}
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/unless}}{{/each}}
      {{#each cnvs}} {{#if this.incidental}} {{#unless this.monogenicDiseaseRisk}}
      <tr>
        <td colspan="4">
          <table class="variant-table">
             <colgroup>
              <col width="140">
              <col width="140">
              <col width="55">
              <col width="75">
              <col width="195">
              <col width="140">
              <col width="145">
            </colgroup>
              <tr>
                <th>Gene & Transcript</th>
                <th>Variant</th>
                <th>Allele State</th>
                <th>Location</th>
                <th>Disorder or Phenotype</th>
                <th>Inheritance</th>
                <th>Classification</th>
              </tr>
              <tr>
                <td>{{this.genes}}<br/>{{this.transcripts}}</td>
                <td>Copy Number {{this.type}}</td>
                <td>{{this.zygosity}}</td>
                <td>{{this.exons}}</td>
                <td>{{this.disorder}}</td>
                <td>{{this.inheritance}}</td>
                <td>{{this.pathogenicity}}</td>
              </tr>
              <tr>
                <th colspan="3" class="padded-cell">Genomic Position</th>
                <th colspan="4" class="padded-cell">Ratio / Z-Score compared to Reference Samples, Mean Read Depth</th>
              </tr>
              <tr>
                <td colspan="3">Chr{{this.chr}}:{{this.start}}-{{this.stop}}</td>
                <td colspan="4">
                  {{this.ratio}} Ratio, {{this.zScore}} Z-Score, {{this.meanReadDepth}} Mean Read Depth
                </td>
              </tr>
              <tr>
                <td colspan="7" class="left-text padded-cell">
                  <span class="blue-text bold-text">VARIANT INTERPRETATION: </span>{{this.interpretation}}
                </td>
              </tr>
          </table>
        </td>
      </tr>
      {{/unless}} {{/if}} {{/each}} 
      {{/ifCond}}
      <tr>
        </td>
      </tr>
      <tr>
        {{#if carrierStatus}}
        <td colspan="4" class="text-sm">
        {{else}}
        <td colspan="4" class="text-sm top-space">
        {{/if}}
          <div class="text-md blue-text bold-text bottom-space">METHODOLOGY</div>
          {{test.method.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm top-space">
          <div class="text-md blue-text bold-text bottom-space">VARIANT ASSESSMENT PROCESS</div>
          {{test.process.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="text-sm top-space">
          <div class="text-md blue-text bold-text bottom-space">LIMITATIONS</div>
          {{test.limitations.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space text-sm">
          <div class="text-md blue-text bold-text bottom-space">REFERENCES</div>
          {{test.references.data}}
        </td>
      </tr>
      <tr>
        <td colspan="4" class="top-space">
          {{#if verification.signOff1.data.[0]}}
          <strong>Approved by:</strong>
          <br/> {{verification.signOff1.data.[1]}} {{verification.signOff1.data.[2]}} ({{dateFormat verification.signOff1.data.[3]}})
          <br/> {{else}}
          <strong>DRAFT REPORT</strong>
          {{/if}}
        </td>
      </tr>
    </tbody>
  </table>
</body>
</html>