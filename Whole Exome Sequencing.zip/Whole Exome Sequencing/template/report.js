import "scripts/handlebars-v3.0.3.js";
import "scripts/lodash.js";
import "scripts/templateUtils.js";

var requiredSources = ["transcript", "acmgclassifer", "zygosity"];
var optionalSources = ["coveragestatistics"];

var requiredSources_cnvs = ["overlapgene"];
var inheritanceChoices = [
  "Autosomal Recessive / Homozygous",
  "Autosomal Recessive / Compound Heterozygous",
  "Autosomal Recessive / Heterozygous",
  "Autosomal Dominant / de Novo",
  "Autosomal Dominant / Heterozygous",
  "Autosomal Imprinted",
  "X-linked Recessive / Homozygous",
  "X-linked Recessive / Hemizygous",
  "X-linked Recessive / Compound Heterozygous",
  "X-linked Dominant / Heterozygous",
  "X-linked Dominant / de Novo",
  "Matrilineal",
  "Y-Linked",
  "Multifactorial",
  "Recessive / Other",
  "Dominant / Other",
  "Other"
];

var prepForIdLookup = function (ctx) {
  for (var key in ctx) {
    if (_.isArray(ctx[key])) {
      ctx[key] = _.indexBy(ctx[key], "id");
    }
  }
  return ctx;
};
// Callback for looking up a variant in the catalog
var lookupVariantAction = function (
  section,
  recordType,
  project,
  input,
  variant
) {
  var paramsById = prepForIdLookup(form.getParamsData());
  var catalogParamName =
    recordType === "variants" ? "variantCatalogPath" : "cnvCatalogPath";
  var catalogUrl = _.get(
    paramsById,
    ["catalogs", catalogParamName, "data"],
    null
  );
  if (!catalogUrl) {
    form.message(
      "You must first use the Configure Report Template dialog to select an assessment catalog to use."
    );
    return;
  }
  var variantId = variant["key"];
  var sampleId = project.samples.Current.entity.Samples;
  var variantData = project[recordType][variantId];
  if (recordType === "variants") {
    var catalogRecords = form.readCatalog(
      catalogUrl,
      variantData.site.Chr,
      variantData.site.Start,
      variantData.site.Stop,
      variantData.site.RefAlt,
      sampleId
    );
  } else {
    var catalogRecords = form.readCatalog(
      catalogUrl,
      variantData.cnvcaller.Chr,
      variantData.cnvcaller.Start,
      variantData.cnvcaller.Stop,
      variantData.cnvcaller.Type,
      sampleId
    );
  }
  if (!catalogRecords || catalogRecords.length === 0) {
    var message = "No catalog record found for " + sampleId;
    form.setFormRecordItemValue(section, variant.key, "action", message);
    return;
  }
  var r = catalogRecords[0];
  var message = "Interpreted by " + r.record.user + " " + r.record.lastSaved;
  form.setFormRecordItemValue(section, variant.key, "action", message);
  var p = _.get(r.fields, "Classification", null);
  if (p) {
    form.setFormRecordItemValue(section, variant.key, "classification", p);
  }
  var h = _.get(r.fields, "Inheritance", null);
  if (h) {
    form.setFormRecordItemValue(section, variant.key, "inheritance", h);
  }
  var d = _.get(r.fields, "Disorder", null);
  if (d) {
    form.setFormRecordItemValue(section, variant.key, "disorder", d);
  }
  var c = _.get(r.fields, "Criteria", null);
  if (c) {
    form.setFormRecordItemValue(section, variant.key, "criteria", c);
  }
  var i = _.get(r.fields, "Interpretation", null);
  if (i) {
    form.setFormRecordItemValue(
      section,
      variant.key,
      "interpretation",
      "<p>" + i + "</p>"
    );
  }
  if (!p && !i) {
    message = "No Classification or Interpretation fields found in catalog";
    form.setFormRecordItemValue(section, variant.key, "action", message);
  }
};

var layout = [{
    id: "patient",
    label: "Patient Information",
    context: "sample", //Used by data binding engine to pass params to autoFill functions
    items: [{
        id: "name",
        label: "Name",
        type: "shortText",
        doc: "Enter patient name",
        required: true,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Name;
        }
      },
      {
        id: "accessionID",
        label: "Anderson ID",
        type: "shortText",
        doc: "Enter accession ID",
        required: true,
        autoFill: function (project, input) {
          return project.samples.Current.entity.AccessionID
        }
      },
      {
        id: "dob",
        label: "Date of Birth",
        doc: "Enter patient birthday",
        type: "dateTimeEdit",
        autoFill: function (project, input) {
          return project.samples.Current.entity.DOB
        }
      },
      {
        id: "sex",
        label: "Sex",
        type: "choice",
        doc: "Select patient sex",
        choices: ["Male", "Female", "Unspecified"],
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Sex
        }
      },
      {
        id: "race",
        label: "Race/Ethnicity",
        type: "shortText",
        doc: "Enter patient race/ethnicity",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Race
        }
      },
      {
        id: "familyNumber",
        label: "Family #",
        type: "shortText",
        doc: "Enter the family number",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.FamilyNumber
        }
      },
      {
        id: "mrn",
        label: "MRN",
        type: "shortText",
        doc: "Enter the medical record number",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.MRN
        }
      },
      {
        id: "facility",
        label: "Referring facility",
        type: "shortText",
        doc: "Enter the referring facility",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Facility
        }
      },
      {
        id: "physician",
        label: "Referring physician",
        type: "shortText",
        doc: "Enter the referring physician",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Physician
        }
      },
      {
        id: "indication",
        label: "Indication for test",
        type: "shortText",
        doc: "Indication of test(s) performed",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Indication
        }
      },
      {
        id: "copies",
        label: "Copies to",
        type: "shortText",
        doc: "",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Copies
        }
      }
    ]
  },
  {
    id: "sample",
    label: "Sample Information",
    context: "sample", //Used by data binding engine to pass params to autoFill functions
    items: [{
        id: "specimen",
        label: "Specimen",
        type: "shortText",
        doc: "Enter the specimen details",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.Specimen;
        }
      },
      {
        id: "coverage",
        type: "shortText",
        label: "Panel Coverage",
        doc: "Percent of defined regions covered at 100x read depth",
        required: false,
        autoFill: function (project, input) {
          try {
            return (
              _.round(
                project.samples.Current.coveragestatistics.Sample100x,
                2
              ) + "%"
            );
          } catch (e) {
            return "";
          }
        }
      },
      {
        id: "avgDp",
        type: "shortText",
        label: "Avg. Read Depth",
        doc: "Average read depth in defined regions",
        required: false,
        autoFill: function (project, input) {
          try {
            return (
              _.round(
                project.samples.Current.coveragestatistics.SampleMeanDepth,
                0
              ) + "x"
            );
          } catch (e) {
            return "";
          }
        }
      },
      {
        id: "collectionDate",
        label: "Date of Collection",
        type: "dateTimeEdit",
        doc: "Date of sample collection",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.DateOfCollection;
        }
      },
      {
        id: "receiptDate",
        label: "Date of Receipt",
        type: "dateTimeEdit",
        doc: "Date sample was received",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.DateOfReceipt;
        }
      },
      {
        id: "reportDate",
        label: "Date of Report",
        type: "dateTimeEdit",
        doc: "Date report issued",
        required: false,
        autoFill: function (project, input) {
          return project.samples.Current.entity.DateOfReport;
        }
      }
    ]
  },
  {
    id: "results",
    label: "Patient Result",
    context: "sample",
    items: [{
        id: "result",
        label: "Result",
        type: "choice",
        doc: "Overall result of test",
        choices: ["Positive", "Negative"]
      },
      {
        id: "resultNote",
        label: "Result Note",
        type: "longText",
        doc: "Short comment to augment result",
        heightInLines: 3,
        autoFill: function (project, input) {
          var note =
            input.results.result == "Positive" ? "Findings" : "No findings";
          note += " explain patient phenotype";
          note += input.incidental.records.length ?
            ", Incidental findings identified." :
            ".";
          return note;
        }
      },
      {
        id: "summary",
        label: "Summary for Primary Findings",
        type: "longText",
        doc: "Summary text for primary findings",
        autoFill: function (project, input) {
          var genes = [];
          var counts = {};
          var atLeastOne = false;
          var variantsNotEvaluated = 0;
          input.variants.records.forEach(function (vr) {
            var v = project.variants[vr.key];
            var classification = vr.classification;
            var g = _.get(v, ["acmgclassifer", "0", "GeneName"], null);
            if (g) {
              if (!_.includes(genes, g)) {
                genes.push(g);
                counts[g] = {
                  pathogenic: 0,
                  likely_pathogenic: 0,
                  uncertain_significance: 0,
                  benign: 0,
                  likely_benign: 0
                };
              }
              if (classification) {
                classification = classification.replace(" ", "_").toLowerCase();
                counts[g][classification]++;
                atLeastOne = true;
              }
            }
          });
          genes.sort();
          var summary = "";
          if (atLeastOne) {
            genes.forEach(function (g) {
              _.forIn(counts[g], function (value, key) {
                if (value) {
                  summary +=
                    (value <= 20 ? numberToWord[value] : value) +
                    " " +
                    key.replace("_", " ") +
                    " variant" +
                    (value != 1 ? "s" : "") +
                    " in " +
                    g +
                    " was identified in this individual. ";
                }
              });
            });
            summary +=
              "No other variants of relevance to the indication were identified. Please see below for more detailed variant information.";
          }
          if (!variantsNotEvaluated) {
            return summary;
          } else {
            return (
              (variantsNotEvaluated <= 20 ?
                numberToWord[variantsNotEvaluated] :
                variantsNotEvaluated) +
              " variant" +
              (variantsNotEvaluated != 1 ? "s were" : " was") +
              " not found in the catalog. Evaluate " +
              (variantsNotEvaluated != 1 ? "them" : "it") +
              " in VSClinical and then rerun the assessment catalog annotation." +
              "\n\n" +
              summary
            );
          }
        }
      },
      {
        id: "summaryIncidental",
        label: "Summary for Incidental Findings",
        type: "longText",
        doc: "Summary text for incidental findings",
        autoFill: function (project, input) {
          return "Incidental findings are variants of medical significance that are not associated with the individual's reported indication. Please note that the presence of pathogenic variants in genes with incomplete coverage or in genes not examined cannot be fully excluded.";
        }
      },
      {
        id: "summaryMonogenicDiseaseRisk",
        label: "Monogenic Disease Risk (IF)",
        type: "longText",
        doc: "Summary text for variants with monogenic disease risk in incidental findings",
        autoFill: function (project, input) {
          var count = 0;
          input.incidental.records.forEach(function (vr) {
            var v = project.variants[vr.key];
            var inheritance = vr.inheritance;
            if (v.Current) {
              var zygosity =
                _.get(v, "Current.Zygosity", null) ||
                _.get(v, "Current.Zygosity2", "");
              if (
                inheritance.indexOf("Dominant") !== -1 ||
                zygosity.indexOf("Homozygous") != -1 ||
                zygosity.indexOf("Hemizygous") != -1
              ) {
                count++;
              }
            }
          });
          if (count) {
            return (
              "This individual has " +
              (count <= 20 ? numberToWord[count].toLowerCase() : count) +
              " variant" +
              (count != 1 ? "s" : "") +
              " in a gene associated with a dominant disorder that is unrelated to this individual's reported phenotype. In the heterozygous state, this variant may infer a partial or complete risk of acquiring the disease if it has not manifested. Please see below for more detailed variant information."
            );
          } else {
            return "There were NO monogenic disease risk variants identified in this individual in genes unrelated to this individual’s clinical presentation. Please see limitations for more detail.";
          }
        }
      },
      {
        id: "summaryCarrierStatus",
        label: "Carrier Status (IF)",
        type: "longText",
        doc: "Summary text for variants with carrier status in incidental findings",
        autoFill: function (project, input) {
          var count = 0;
          input.incidental.records.forEach(function (vr) {
            var v = project.variants[vr.key];
            var inheritance = vr.inheritance;
            if (v.Current) {
              var zygosity =
                _.get(v, "Current.Zygosity", null) ||
                _.get(v, "Current.Zygosity2", "");
              if (
                !(
                  inheritance.indexOf("Dominant") !== -1 ||
                  zygosity.indexOf("Homozygous") != -1 ||
                  zygosity.indexOf("Hemizygous") != -1
                )
              ) {
                count++;
              }
            }
          });
          if (count) {
            return (
              "This individual is a carrier of " +
              (count <= 20 ? numberToWord[count].toLowerCase() : count) +
              " heterozygous pathogenic variant" +
              (count != 1 ? "s" : "") +
              " in a gene associated with a recessive disorder that is unrelated to this individual’s reported phenotype. In the heterozygous state, this variant is not known to play a role in disease. Please see below for more detailed variant information."
            );
          } else {
            return "There were NO variants inferring a carrier status of a recessive disorder identified in this individual in genes unrelated to this individual’s clinical presentation. Please see limitations for more detail.";
          }
        }
      }
    ]
  },
  // Creates a "variant" sub-widget, which is configured to be filled in
  // with a set of variants selected by the user
  {
    id: "variants",
    label: "Primary Findings",
    context: "variant",
    items: [{
        id: "description",
        label: "Variant",
        type: "label",
        doc: "Chr:Pos Ref/Alt (Gene Name)",
        autoFill: function (project, input, variant) {
          var posStr =
            variant.site.Chr +
            ":" +
            (variant.site.Start + 1) +
            " " +
            variant.site.RefAlt;
          var hgvs = _.get(variant, ["acmgclassifer", "0", "HGVScDot"], null);
          var gene = _.get(variant, ["acmgclassifer", "0", "GeneName"], null);
          var geneStr = gene ? "(<i>" + gene + "</i>)" : "";
          return hgvs + "<br>" + posStr + " " + geneStr;
        }
      },
      {
        id: "action",
        type: "action",
        label: "Catalog Lookup",
        buttonText: "Lookup",
        buttonIcon: "reload_gray",
        text: "Fill in interpretation from a catalog...",
        doc: "Configure a catalog that has a classification and interpretation field and look up the current variant and sample in that catalog.",
        action: _.curry(lookupVariantAction)("variants", "variants")
      },
      {
        id: "classification",
        label: "Classification",
        type: "choice",
        doc: "Classification of variant (from assessment database, if used)",
        choices: [
          "Pathogenic",
          "Likely Pathogenic",
          "Uncertain Significance",
          "Likely Benign",
          "Benign"
        ]
      },
      {
        id: "criteria",
        label: "Criteria",
        type: "shortText",
        doc: "The ACMG criteria for the variant"
      },
      {
        id: "inheritance",
        label: "Inheritance",
        type: "choice",
        doc: "Inheritance of variant",
        choices: inheritanceChoices
      },
      {
        id: "disorder",
        label: "Disorder",
        type: "shortText",
        doc: "The disorder/phenotype for the variant"
      },
      {
        id: "interpretation",
        label: "Interpretation",
        type: "richTextEdit",
        doc: "Interpretation of variant (from assessment database, if used)",
        heightInLines: 5
      }
    ]
  },
  // A separate variant sub-widget, containing a different set of variants (not guaranteed mutually exclusive)
  {
    id: "incidental",
    label: "Incidental Findings",
    context: "variant",
    items: [{
        id: "description",
        label: "Variant",
        type: "label", //Non-editable
        format: "bold", //Potential style hint
        autoFill: function (project, input, variant) {
          var posStr =
            variant.site.Chr +
            ":" +
            (variant.site.Start + 1) +
            " " +
            variant.site.RefAlt;
          var gene = _.get(variant, ["acmgclassifer", "0", "GeneName"], null);
          var geneStr = gene ? "(<i>" + gene + "</i>)" : "";
          return posStr + " " + geneStr;
        }
      },
      {
        id: "action",
        type: "action",
        label: "Catalog Lookup",
        buttonText: "Lookup",
        buttonIcon: "reload_gray",
        text: "Fill in interpretation from a catalog...",
        doc: "Configure a catalog that has a classification and interpretation field and look up the current variant and sample in that catalog.",
        action: _.curry(lookupVariantAction)("incidental", "variants")
      },
      {
        id: "classification",
        label: "Classification",
        type: "choice",
        doc: "Classification of variant (from assessment database, if used)",
        choices: [
          "Pathogenic",
          "Likely Pathogenic",
          "Uncertain Significance",
          "Likely Benign",
          "Benign"
        ]
      },
      {
        id: "criteria",
        label: "Criteria",
        type: "shortText",
        doc: "The ACMG criteria for the variant"
      },
      {
        id: "inheritance",
        label: "Inheritance",
        type: "choice",
        doc: "Inheritance of variant",
        choices: inheritanceChoices
      },
      {
        id: "disorder",
        label: "Disorder",
        type: "shortText",
        doc: "The disorder/phenotype for the variant"
      },
      {
        id: "interpretation",
        label: "Interpretation",
        type: "richTextEdit",
        doc: "Interpretation of variant (from assessment database, if used)",
        heightInLines: 5
      }
    ]
  },
  {
    id: "cnvs",
    label: "CNV Findings",
    context: "cnv",
    items: [{
        id: "description",
        label: "CNV",
        type: "label",
        doc: "Chr:Pos Ref/Alt (Gene Name)",
        autoFill: function (project, input, record) {
          return templateUtils.cnvTitle(record);
        }
      },
      {
        id: "action",
        type: "action",
        label: "Catalog Lookup",
        buttonText: "Lookup",
        buttonIcon: "reload_gray",
        text: "Fill in interpretation from a catalog...",
        doc: "Configure a CNV catalog that has a classification and interpretation field and look up the current CNV and sample in that catalog.",
        action: _.curry(lookupVariantAction)("cnvs", "cnvs")
      },
      {
        id: "reportAs",
        label: "Report As",
        type: "radio",
        doc: "Report CNV Findings as either Primary or Incidental",
        choices: ["Primary", "Incidental"],
        horizontalLayout: true
      },
      {
        id: "classification",
        label: "Classification",
        type: "choice",
        doc: "Classification of CNV",
        choices: [
          "Pathogenic",
          "Likely Pathogenic",
          "Uncertain Significance",
          "Likely Benign",
          "Benign"
        ]
      },
      {
        id: "inheritance",
        label: "Inheritance",
        type: "choice",
        doc: "Inheritance of variant",
        choices: ["Dominant", "Recessive"]
      },
      {
        id: "disorder",
        label: "Disorder",
        type: "shortText",
        doc: "The disorder/phenotype for the variant"
      },
      {
        id: "interpretation",
        label: "Interpretation",
        type: "richTextEdit",
        doc: "Interpretation of this variant",
        heightInLines: 5
      }
    ]
  },
  {
    id: "verification",
    label: "Report Signoff",
    context: "sample",
    items: [{
      id: "signOff1",
      label: "Verify",
      type: "signOff",
      doc: "Record user and time of sign off"
    }]
  }
];

var numberToWord = {
  1: "One",
  2: "Two",
  3: "Three",
  4: "Four",
  5: "Five",
  6: "Six",
  7: "Seven",
  8: "Eight",
  9: "Nine",
  10: "Ten",
  11: "Eleven",
  12: "Twelve",
  13: "Thirteen",
  14: "Fourteen",
  15: "Fifteen",
  16: "Sixteen",
  17: "Seventeen",
  18: "Eighteen",
  19: "Nineteen",
  20: "Twenty"
};

// Makes lodash templates use curly braces
_.templateSettings.interpolate = /{{([\s\S]+?)}}/g;

// Handlebars Helpers
Handlebars.registerHelper("if_all", function () {
  var args = [].slice.apply(arguments);
  var opts = args.pop();

  var fn = opts.fn;
  for (var i = 0; i < args.length; ++i) {
    if (args[i]) continue;
    fn = opts.inverse;
    break;
  }
  return fn(this);
});

Handlebars.registerHelper("eachInMap", function (map, block) {
  var out = "";
  Object.keys(map).map(function (prop) {
    out += block.fn({
      key: prop,
      value: map[prop]
    });
  });
  return out;
});

Handlebars.registerHelper("dateFormat", function (context) {
  var date = new Date(context);
  return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear();
});

Handlebars.registerHelper("pToRows", function (context) {
  var pTags = context.match(/<p>[\s\S]*?<\/p>/gi);
  var s = "";
  for (var i = 0; i < pTags.length; ++i) {
    s += '<tr><td colspan="18">  ';
    s += pTags[i];
    s += "</td></tr>";
  }
  return s;
});

Handlebars.registerHelper("lower", function (context) {
  var lower = context.toLowerCase();
  return lower;
});

Handlebars.registerHelper("ifCond", function (v1, operator, v2, options) {
  switch (operator) {
    case "==":
      return v1 == v2 ? options.fn(this) : options.inverse(this);
    case "===":
      return v1 === v2 ? options.fn(this) : options.inverse(this);
    case "!=":
      return v1 != v2 ? options.fn(this) : options.inverse(this);
    case "!==":
      return v1 !== v2 ? options.fn(this) : options.inverse(this);
    case "<":
      return v1 < v2 ? options.fn(this) : options.inverse(this);
    case "<=":
      return v1 <= v2 ? options.fn(this) : options.inverse(this);
    case ">":
      return v1 > v2 ? options.fn(this) : options.inverse(this);
    case ">=":
      return v1 >= v2 ? options.fn(this) : options.inverse(this);
    case "&&":
      return v1 && v2 ? options.fn(this) : options.inverse(this);
    case "||":
      return v1 || v2 ? options.fn(this) : options.inverse(this);
    default:
      return options.inverse(this);
  }
});

constructVariant = function (inputVariant, variantDatas) {
  var variant = {};
  var variantData = variantDatas[inputVariant.key];

  variant.gene = _.chain(variantData)
    .get(["acmgclassifer", "0", "GeneName"], "N/A")
    .value();
  variant.effect = _.chain(variantData)
    .get(["acmgclassifer", "0", "SequenceOntology"], "N/A")
    .split("_")
    .slice(0, -1)
    .map(_.capitalize)
    .value();

  variant.zygosity =
    _.get(variantData, "Current.Zygosity", null) ||
    _.get(variantData, "Current.Zygosity2", "");

  variant.zygosity =
    variant.zygosity == "Hemizygous" ?
    variant.zygosity.substring(0, 4) + "." :
    variant.zygosity.substring(0, 3) + ".";

  variant.chr = variantData.site.Chr;

  // ACMG classifier data
  variant.transcript = _.get(
    variantData,
    ["acmgclassifer", "0", "TranscriptName"],
    null
  );

  variant.maxAlleleFreq = _.get(
    variantData,
    ["acmgclassifer", "0", "MaxMAF"],
    null
  );
  variant.maxAlleleFreq =
    variant.maxAlleleFreq != null ?
    (variant.maxAlleleFreq * 100).toFixed(3) + "%" :
    null;
  variant.maxPop = _.get(
    variantData,
    ["acmgclassifer", "0", "MaxSubPopulationFreqGroupName"],
    null
  );

  variant.hgvsG = _.get(variantData, ["transcript_2", "0", "HGVSg"], null);
  variant.hgvsC = _.get(variantData, ["acmgclassifer", "0", "HGVScDot"], null);
  variant.hgvsC =
    variant.hgvsC != null && variant.hgvsC != "?" ?
    variant.hgvsC.split(":")[1] :
    null;
  variant.hgvsP = _.get(variantData, ["acmgclassifer", "0", "HGVSpDot"], null);
  variant.hgvsP =
    variant.hgvsP != null && variant.hgvsP != "?" ?
    variant.hgvsP.split(":")[1] :
    null;

  variant.disorder = _.get(inputVariant, "disorder", "");
  variant.inheritance = _.get(inputVariant, "inheritance", "");

  variant.monogenicDiseaseRisk =
    variant.inheritance.indexOf("Dominant") !== -1 ||
    variant.zygosity == "Hom." ||
    variant.zygosity == "Hemi.";

  variant.exon = _.chain(variantData)
    .get("transcript.ExonNumberClinicallyRelevant", ["N/A"])
    .map(function (num) {
      return num > 0 ? "Exon " + num : "N/A";
    })
    .value()
    .join(",");

  var allelicReadDepths = "";
  var readDepths = _.get(variantData, "Current.AD", []);
  var alleles = _.get(variantData, "site.RefAlt", "").split("/");
  readDepths.forEach(function (d, i) {
    if (i >= alleles.length) {
      return;
    }
    if (i === 0) {
      allelicReadDepths = "Ref(" + alleles[i] + "): " + d;
    } else {
      allelicReadDepths += ", Alt(" + alleles[i] + "): " + d;
    }
  });
  if (allelicReadDepths) {
    var vafs = _.get(variantData, "Current.VAF", []);
    vafs.forEach(function (v) {
      allelicReadDepths += ", VAF: " + (v * 100).toFixed(2) + "%";
    });
  }
  variant.allelicReadDepths = allelicReadDepths;

  var urlRe = /<a href="/g;
  var replacement = '<a target="_blank" href="';

  variant.criteria = _.get(inputVariant, "criteria", "");

  variant.pathogenicity = _.get(inputVariant, "classification", "");
  variant.interpretation = _.get(inputVariant, "interpretation", "").replace(
    urlRe,
    replacement
  );

  return variant;
};

constructCNV = function (inputCnv, cnvDatas) {
  var cnv = {};
  var cnvData = cnvDatas[inputCnv.key];

  cnv.title = templateUtils.cnvTitle(cnvData, cnv);

  var urlRe = /<a href="/g;
  var replacement = '<a target="_blank" href="';

  cnv.interpretation = _.get(inputCnv, "interpretation", "").replace(
    urlRe,
    replacement
  );

  cnv.pathogenicity = _.get(inputCnv, "classification", "");
  cnv.disorder = _.get(inputCnv, "disorder", "");
  cnv.inheritance = _.get(inputCnv, "inheritance", "");
  cnv.primary = _.get(inputCnv, "reportAs", "") === "Primary";
  cnv.incidental = _.get(inputCnv, "reportAs", "") === "Incidental";
  cnv.monogenicDiseaseRisk = cnv.inheritance === "Dominant";
  cnv.chr = _.get(cnvData, ["cnvcaller", "Chr"], null);
  cnv.start = _.get(cnvData, ["cnvcaller", "Start"], null);
  cnv.stop = _.get(cnvData, ["cnvcaller", "Stop"], null);
  cnv.type = _.get(cnvData, ["cnvcaller", "Type"], null);
  cnv.zygosity = _.get(cnvData, "Current.CNVState", "");
  cnv.zygosity = cnv.zygosity.substring(0, 3) + ".";
  cnv.ratio = _.chain(cnvData)
    .get("Current.AvgRatio", 1.0)
    .value()
    .toFixed(3);
  cnv.zScore = _.chain(cnvData)
    .get("Current.AvgZScore", 0.0)
    .value()
    .toFixed(3);
  cnv.meanReadDepth = _.chain(cnvData)
    .get("Current.AvgTargetMeanDepth", 0.0)
    .value()
    .toFixed(3);
  var exons = _.chain(cnvData)
    .get(["overlapgene", "OverlappingExonsClinicallyRelevant"], ["N/A"])
    .map(function (val) {
      return val !== "?" && val != undefined ?
        (val.indexOf("-") >= 0 ? "Exons " : "Exon ") + val :
        "N/A";
    })
    .value();
  cnv.genes = _.get(cnvData, ["overlapgene", "GeneNames"], [])
    .filter(function (v, i) {
      return exons[i] !== "N/A";
    })
    .join(",");
  cnv.transcripts = _.get(
      cnvData,
      ["overlapgene", "TranscriptNameClinicallyRelevant"],
      []
    )
    .filter(function (v, i) {
      return exons[i] !== "N/A";
    })
    .join(",");
  cnv.exons = exons
    .filter(function (v) {
      return v !== "N/A";
    })
    .join(",");
  return cnv;
};

groupVariantsByGene = function (variants) {
  // variants from inputData
  var variantsByGene = _.groupBy(variants, "gene");
  return variantsByGene;
};

preprocessContext = function (ctx, projectData) {
  var curried = _.curryRight(constructVariant)(projectData.variants);
  var curriedCNV = _.curryRight(constructCNV)(projectData.cnvs);
  for (var key in ctx) {
    if (key === "references") {
      continue;
    } else if (key === "variants" || key === "incidental") {
      ctx[key] = _.map(ctx[key].records, function (item) {
        return curried(item);
      });
      if (key === "incidental") {
        ctx[key].forEach(function (v) {
          if (v.monogenicDiseaseRisk) {
            ctx.monogenicDiseaseRisk = true;
          } else {
            ctx.carrierStatus = true;
          }
        });
      }
    } else if (key === "cnvs") {
      ctx[key] = _.map(ctx[key].records, function (item) {
        return curriedCNV(item);
      });
      ctx[key].forEach(function (v) {
        if (v.primary) {
          ctx.cnvPrimary = true;
        } else {
          ctx.cnvIncidental = true;
          if (v.monogenicDiseaseRisk) {
            ctx.monogenicDiseaseRisk = true;
          } else {
            ctx.carrierStatus = true;
          }
        }
      });
    } else if (_.isArray(ctx[key])) {
      ctx[key] = _.indexBy(ctx[key], "id");
    }
  }
  return ctx;
};

createGeneSummary = function (params, project, input) {
  var geneSummary = [];
  if (!_.find(params.test, {
      id: "coveredGenes"
    })) return [];
  var geneArr = _.chain(params.test)
    .find({
      id: "coveredGenes"
    })
    .get("data")
    .split(",")
    .map(_.trim)
    .invoke(String.prototype.toUpperCase)
    .sort()
    .value();
  _.forEach(geneArr, function (name) {
    var summary = {};
    var number = _.chain(project.variants)
      .values()
      .pluck("transcript.GeneNames")
      .filter(function (arr) {
        return _.some(arr, function (g) {
          return g === name;
        });
      })
      .value().length;
    summary.geneName = name;
    summary.numVariants = number;
    geneSummary.push(summary);
  });
  return geneSummary;
};

// You can define a custom render function, or you can use the system provided one, which looks like
var render = function (
  templateText, //Loaded by program, passed as arg
  params, // global params JSON object
  project, // project object, has 'sample' and 'variant' key
  input // keys defined defined by layout
) {
  var labeledInput = templateUtils.labelInput(layout, input);
  var ctx = _.extend(labeledInput, params);
  ctx = preprocessContext(ctx, project);

  var records = _.get(input, "variants.records", [])
    .concat(_.get(input, "incidental.records"))
    .concat(_.get(input, "cnvs.records", []));
  var variantList = _.get(ctx, "variants", []);
  ctx.references = templateUtils.getReferences(records, project.variants);
  _.extend(ctx.references, templateUtils.getReferences(records, project.cnvs));
  ctx.variantsByGene = groupVariantsByGene(variantList);
  ctx.geneSummary = createGeneSummary(params, project, input);
  ctx.reportName = project.samples.Current.entity.Name + " Report";

  var template = Handlebars.compile(templateText, {
    noEscape: true
  });
  return template(ctx);
};

var reportFileName = function (reportName, project, input) {
  return project.samples.Current.entity.Name + ".html";
};
